/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package questao_1_laysonbatista;

import java.awt.Component;
import java.io.DataInputStream;
import javax.swing.JOptionPane;

/**
 *
 * @author aluno
 */
public class Questao_1_LaysonBatista {

    private static Component rootPane;

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        DataInputStream dado = new DataInputStream(System.in);
        
        String s = "";
        int anos = 0;
        int anosEmDias = 365;
        int mes = 0;
        int mesEmDias = 30;
        int dias = 0;
        int totalDias = 0;
       
        
        s = JOptionPane.showInputDialog(null,"Informe sua idade (em anos): ");
        anos = Integer.parseInt(s);
        
        s = JOptionPane.showInputDialog(null,"Informe os meses: ");
        mes = Integer.parseInt(s);
        
        s = JOptionPane.showInputDialog(null,"Informe os dias: ");
        dias = Integer.parseInt(s);
        
        totalDias = (anos * anosEmDias) + (mes * mesEmDias) + dias;
        
        JOptionPane.showMessageDialog(rootPane,anos + " anos, " + mes + " meses e " + dias + " dias = " + totalDias);
       
        
    }
    
}
