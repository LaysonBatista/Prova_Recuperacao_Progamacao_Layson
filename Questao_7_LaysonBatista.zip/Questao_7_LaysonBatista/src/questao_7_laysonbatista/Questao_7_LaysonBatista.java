/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package questao_7_laysonbatista;

import java.awt.Component;
import java.io.DataInputStream;
import javax.swing.JOptionPane;

/**
 *
 * @author aluno
 */
public class Questao_7_LaysonBatista {

    private static Component rootPane;

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        DataInputStream dado = new DataInputStream(System.in);
        
        String s ="";
        
        String nomeJ1 = null;
        String nomeJ2 = null;
        String j2Resposta = null;
        String nomeFilme = null;
        String pista1 = null;
        String pista2 = null;
        
        s = JOptionPane.showInputDialog(null,"Nome do J1: ");
        nomeJ1 = String.valueOf(s);
        
        s = JOptionPane.showInputDialog(null,"Filme escolhido: ");
        nomeFilme = String.valueOf(s);
        
        s = JOptionPane.showInputDialog(null,"infomorme a pista 1: ");
        pista1 = String.valueOf(s);
        
        s = JOptionPane.showInputDialog(null,"infomorme a pista 2: ");
        pista2 = String.valueOf(s);
        
        
        
        s = JOptionPane.showInputDialog(null,"nome J2: ");
        nomeJ2 = String.valueOf(s);
        
        
        
        JOptionPane.showMessageDialog(rootPane,"Olá, " + nomeJ2 + "a pista 1 é: " + pista1);
        JOptionPane.showMessageDialog(rootPane,"Olá, " + nomeJ2 + "a pista 2 é: " + pista2);
        
        JOptionPane.showInputDialog(rootPane,"Então, " + nomeJ2 + " qual o nome do filme? ");
        
        
        
        
        
    }
    
}
