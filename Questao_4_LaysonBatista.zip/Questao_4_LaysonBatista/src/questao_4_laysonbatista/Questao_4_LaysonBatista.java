/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package questao_4_laysonbatista;

import java.awt.Component;
import java.io.DataInputStream;
import javax.swing.JOptionPane;

/**
 *
 * @author aluno
 */
public class Questao_4_LaysonBatista {

    private static Component rootPane;

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
         DataInputStream dado = new DataInputStream(System.in);
         
         String s ="";
         
         int num = 0;
         
        s = JOptionPane.showInputDialog(null,"Informe o primeiro numero: ");
        num = Integer.parseInt(s);
        
      
        if(num == 1){
            JOptionPane.showMessageDialog(rootPane,"Janeiro");
        } else if(num == 2 ){
            JOptionPane.showMessageDialog(rootPane,"Fevereiro");
        } else if(num == 3){
          JOptionPane.showMessageDialog(rootPane,"Março");  
        } else if(num == 4){
            JOptionPane.showMessageDialog(rootPane,"Abril");
        } else if(num == 5){
            JOptionPane.showMessageDialog(rootPane,"Maio");
        } else if( num == 6){
            JOptionPane.showMessageDialog(rootPane,"Junho");
        } else if(num == 7){
            JOptionPane.showMessageDialog(rootPane,"Julho");
        } else if(num ==8){
            JOptionPane.showMessageDialog(rootPane,"agosto");
        } else if(num ==9){
            JOptionPane.showMessageDialog(rootPane,"Setembro");
        } else if(num == 10){
            JOptionPane.showMessageDialog(rootPane,"Outubro");
        } else if(num == 11){
            JOptionPane.showMessageDialog(rootPane,"Novembro");
        }else if(num == 12){
            JOptionPane.showMessageDialog(rootPane,"Dezembro");
        } else {
            JOptionPane.showMessageDialog(rootPane,"INVALIDO");
        }
        
        
        
    }
    
}
