/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package questao_5_laysonbatista;

import java.awt.Component;
import java.io.DataInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import javax.swing.JOptionPane;

/**
 *
 * @author aluno
 */
public class Questao_5_LaysonBatista {

    private static Component rootPane;

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        
        DataInputStream dado = new DataInputStream(System.in);
        
     
     
         String s ="";
         int numTabuada = 0;
         int n = 0;
         
          s = JOptionPane.showInputDialog(null,"Informe o numero da tabuada que deseja: ");
        numTabuada = Integer.parseInt(s);
        
           FileWriter arq = new FileWriter("C:\\User\\aluno\\Desktop\\tabuada de " + numTabuada + ".txt");
           PrintWriter gravarArq = new PrintWriter(arq);
           
           gravarArq.printf("Nome: tabuada de " + numTabuada);
           
           for(n = 1; n <=10; n++){
               gravarArq.printf("| " + n + " X " + numTabuada + " = " + (n*numTabuada));
           }
           
           JOptionPane.showMessageDialog(rootPane,"tabuada de " + numTabuada + " concluida com sucesso!");
           
           
        
        
        
        
    }
    
}
