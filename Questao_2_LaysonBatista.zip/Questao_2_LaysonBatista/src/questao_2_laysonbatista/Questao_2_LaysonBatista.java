/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package questao_2_laysonbatista;

import java.awt.Component;
import java.io.DataInputStream;
import java.util.Scanner;
import javax.swing.JOptionPane;

/**
 *
 * @author aluno
 */
public class Questao_2_LaysonBatista {

    private static Component rootPane;


    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        DataInputStream dado = new DataInputStream(System.in);
        Scanner scanner = new Scanner(System.in);
        
        String s = "";
        int parar = 0;
        int escolha = 0;
      
        int quantidadeCafeExpresso = 0;
        int quantidadeCafeCapuccino = 0;
        int quantidadeCafeComLeite = 0;
        
        double valorCafeExpresso = 0.75;
        double valorCafeCapuccino = 1.00;
        double valorCafeComLeite = 1.25;
        
        String[] opcoesDaMaquina = new String[]{"cafe expresso", "cafe capuccino", "leite com cafe"};
        
         System.out.println("<<<Maquina de cafe>>>");
        
          System.out.println("Escolha algum cafe para comprar digitando o numero do mesmo!");
          
         do{ 
        for(int i = 0; i < opcoesDaMaquina.length; i++){
             System.out.println("[" + i + "]" + opcoesDaMaquina[i]);
        }
        
         System.out.println("Qual cafe deseja ecolher? ");
         escolha = scanner.nextInt();
        
        
         if(escolha == 0){
             quantidadeCafeExpresso++;
             
         } else if(escolha == 1){
             quantidadeCafeCapuccino++;
         } else if(escolha == 2){
             quantidadeCafeComLeite++;
         }
         
         System.out.println("Para encerrar digite 9!(para continuar digite qualquer outro numero): ");
         parar = scanner.nextInt();
         
         }while(parar != 9);
         
         
         System.out.println("\nQuantidade de cafe expresso vendidos: " + quantidadeCafeExpresso + "\nValor de cada um: " + valorCafeExpresso);
         System.out.println("\nQuantidade de cafe capuccino vendidos: " + quantidadeCafeCapuccino + "\nValor de cada um: " + valorCafeCapuccino);
         System.out.println("\nQuantidade de cafe com leite vendidos: " + quantidadeCafeComLeite + "\nValor de cada um: " + valorCafeComLeite);
         
         scanner.close();
    }
    
}
