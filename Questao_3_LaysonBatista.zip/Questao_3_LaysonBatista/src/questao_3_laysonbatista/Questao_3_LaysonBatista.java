/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package questao_3_laysonbatista;

import java.awt.Component;
import java.io.DataInputStream;
import javax.swing.JOptionPane;

/**
 *
 * @author aluno
 */
public class Questao_3_LaysonBatista {

    private static Component rootPane;

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
         DataInputStream dado = new DataInputStream(System.in);
         
         int seq = 1;
         int num1 = 0;
         int num2 = 0;
         int sequencia = num1 + seq;
         
         
         String s ="";
         
        s = JOptionPane.showInputDialog(null,"Informe o primeiro numero: ");
        num1 = Integer.parseInt(s);
        
        s = JOptionPane.showInputDialog(null,"Informe o segundo numero ");
        num2 = Integer.parseInt(s);
        
        for(int i = num1; i < num2; i++){
        sequencia++;
        JOptionPane.showMessageDialog(rootPane,"os numeros nesse entre eles são: " + sequencia); 
        }
    }
    
}
