/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package questao_6_laysonbatista;

import java.awt.Component;
import java.io.DataInputStream;
import javax.swing.JOptionPane;

/**
 *
 * @author aluno
 */
public class Questao_6_LaysonBatista {

    private static Component rootPane;
    private static Component rootpane;

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
         DataInputStream dado = new DataInputStream(System.in);
         
         String s ="";
         
         double ganhoPorHora = 0;
         double horasTrabalhadasNoMes = 0;
         double bruto = 0;
         double conta = 0;
         
         
         
          
         
         s = JOptionPane.showInputDialog(null,"Quanto voce ganha por hora? ");
        ganhoPorHora = Integer.parseInt(s);
        
        s = JOptionPane.showInputDialog(null,"Quantas horas trablhadas no mes? ");
        horasTrabalhadasNoMes = Integer.parseInt(s);
        
        bruto = horasTrabalhadasNoMes * ganhoPorHora;
        
        double descontoImpostoDeRenda =  bruto / 11;
        double descontoInss = bruto / 8;
        double sindicato = bruto/5;
         
        double descontos = descontoImpostoDeRenda + descontoInss + sindicato;
        
        double liquido = bruto - descontos;
        
        
       
                
      JOptionPane.showMessageDialog(rootpane,"salario bruto: " + bruto + "\ndesconto do inss: " + descontoInss + "\ndesconto imposto de renda: " 
              +descontoImpostoDeRenda + "\ndesconto do sindicato " + sindicato);
                
       
        
        JOptionPane.showMessageDialog(rootPane,"liquido: " + liquido);
        
    }
    
}
